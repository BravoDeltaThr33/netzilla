"""netzilla — a retro terminal toolkit for network administrators."""

__version__ = "4.1.0"
