"""One module per tab."""
