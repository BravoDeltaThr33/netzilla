"""Local tooling.

Work that is better done on the machine than through a third party: subnet
maths, dig/whois, openssl, ping/traceroute/mtr, the offline OUI table and
speedtest. All of it is free, has no rate limit, and keeps working with the
network intelligence APIs unreachable.
"""
