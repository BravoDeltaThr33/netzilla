"""Graphics: terminal-aware graphs.

termcaps.py decides whether this terminal can show pixels; kitty.py speaks
the image protocol; plot.py draws the pixel graphs; charts.py picks pixel or
text for each graph and lays both out identically.
"""
