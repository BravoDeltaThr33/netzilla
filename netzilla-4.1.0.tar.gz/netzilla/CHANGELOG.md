# Changelog

## 4.1.0

First public release.

- **DASH** fills the screen: a centred logo, then panels side by side — this
  machine, the network (interface, addresses, gateway, DNS servers, Wi-Fi,
  public IP), the terminal, local tools, API key status, data and cache, a
  live network-pulse graph of the default interface and API quota. Three
  columns on a wide terminal, fewer on a narrow one.
- **SETTINGS** in two columns: buttons on top, API keys on the left,
  appearance, display and behaviour on the right, and a keys-and-storage
  panel.
- **Bring your own keys.** netzilla ships with no API keys. Keys from free
  AbuseIPDB, VirusTotal, GreyNoise and abuse.ch accounts (and, optionally,
  NVD) are entered on SETTINGS or set as `NETZILLA_<KEY>` environment
  variables. Every tab works without them.
- **Pixel graphs** in kitty 0.28+ and Ghostty 1.0+ (kitty graphics protocol
  with Unicode placeholders); text graphs in every other terminal, chosen
  automatically after asking the terminal what it is.
- **Free and open sources only**: IP-API, AbuseIPDB, VirusTotal, GreyNoise,
  abuse.ch, RDAP, DNS-over-HTTPS, SSL Labs, crt.sh, RIPEstat, Team Cymru,
  NVD, CISA KEV, FIRST EPSS, Shodan InternetDB, endoflife.date, EOSL.ai,
  OutageDeck, Cloudflare's speed-test endpoints and Have I Been Pwned.
- Twenty-one tabs, seventeen themes, one-shot CLI commands with `--json`,
  and 689 tests.
